# 奶茶物语（milktea-saga）

一个用 **Java 21 + 原生 JDBC + MySQL** 写的控制台点单系统，配套文章：

《1600 行写一个奶茶店点单系统：11 个 bug 和它们教我的事》

## 环境

- JDK 21
- MySQL 8.x
- Maven 3.9+（或直接用 IntelliJ IDEA）

## 运行

```bash
# 1. 初始化数据库（会 DROP 并重建 milktea_saga，确认后再执行）
mysql -u root -p --default-character-set=utf8mb4 < sql/init.sql

# 2. 修改连接信息
#    src/main/java/com/tea/util/DbUtil.java 里的 USERNAME / PASSWORD
#    下载版已把密码替换成占位符 YOUR_DB_PASSWORD

# 3. 编译并运行
mvn compile
mvn dependency:build-classpath -Dmdep.outputFile=cp.txt
java -cp "target/classes;$(cat cp.txt)" com.tea.Main
```

Windows 的 classpath 分隔符是 `;`，Linux/macOS 用 `:`。也可以直接在 IntelliJ IDEA 里运行 `Main`。

## 测试账号

| 用户名 | 密码 |
|---|---|
| `xiaoli` | `123456` |
| `xiaowang` | `123456` |
| `linboss` | `888888` |

仅用于教学演示。

## 目录结构

```text
milktea-saga/
├── pom.xml
├── sql/init.sql                  # 建库、建表、测试数据
└── src/main/java/com/tea/
    ├── Main.java                 # 控制台入口：菜单、输入输出、流程编排
    ├── entity/                   # 数据实体
    ├── dao/                      # SQL、参数绑定、ResultSet 映射
    ├── service/                  # 业务规则、校验、事务
    └── util/DbUtil.java          # JDBC 连接工具
```

## 注意

- 密码明文存储、数据库凭据硬编码，仅用于学习，不要直接用于生产。
- `init.sql` 开头会删除并重建数据库，重复执行会清空数据。
- 测试订单日期写死在 2026-06，时间久了「本月统计」会查不到数据。
