package com.tea.dao;

import com.tea.entity.OrderItem;
import com.tea.util.DbUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class OrderItemDao {
    public void insertWithConn(Connection conn, OrderItem item) throws SQLException {
        String sql = "INSERT INTO order_item "
                + "(order_id,drink_id,quantity,unit_price,subtotal) "
                + "VALUES (?,?,?,?,?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, item.getOrderId());
            ps.setLong(2, item.getDrinkId());
            ps.setInt(3, item.getQuantity());
            ps.setBigDecimal(4, item.getUnitPrice());
            ps.setBigDecimal(5, item.getSubtotal());
            ps.executeUpdate();
        }
    }

    public List<OrderItem> findByOrderIdWithDrinkName(Long orderId) {
        String sql = "SELECT oi.id,oi.order_id,oi.drink_id,oi.quantity,oi.unit_price,oi.subtotal,d.name AS drink_name "
                + "FROM order_item oi "
                + "JOIN drink d ON d.id=oi.drink_id "
                + "WHERE oi.order_id=? "
                + "ORDER BY oi.id";
        List<OrderItem> list = new ArrayList<>();
        try (Connection conn = DbUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, orderId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    OrderItem item = new OrderItem();
                    item.setId(rs.getLong("id"));
                    item.setOrderId(rs.getLong("order_id"));
                    item.setDrinkId(rs.getLong("drink_id"));
                    item.setQuantity(rs.getInt("quantity"));
                    item.setUnitPrice(rs.getBigDecimal("unit_price"));
                    item.setSubtotal(rs.getBigDecimal("subtotal"));
                    item.setDrinkName(rs.getString("drink_name"));
                    list.add(item);
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("查询订单明细失败",e);
        }
        return list;
    }
}