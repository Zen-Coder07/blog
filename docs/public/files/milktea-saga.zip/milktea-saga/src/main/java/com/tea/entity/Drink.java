package com.tea.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class Drink {
    private Long id;
    private String name;
    private String category;
    private BigDecimal price;
    private Integer stock;
    private Integer isActive;
    private LocalDateTime createdAt;
    public  Drink() {
    }
    public Drink( String name, String category, BigDecimal price, Integer stock) {
        this.name=name;
        this.category=category;
        this.price=price;
        this.stock=stock;
    }

    public String getName() {
        return name;
    }

    public BigDecimal getPrice() {
        return price;
    }
    public Integer getStock() {
        return stock;
    }
    public Integer getIsActive() {
        return isActive;
    }
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public void setName(String name) {
        this.name = name;
    }
    public void setPrice(BigDecimal price) {
        this.price = price;
    }
    public void setStock(Integer stock) {
        this.stock = stock;
    }
    public void setIsActive(Integer isActive) {
        this.isActive = isActive;
    }
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
    public String getCategory() {
        return category;
    }
    public void setCategory(String category) {
        this.category = category;
    }
    @Override
    public String toString() {
        return String.format("[%d] %-12s ¥%-6s 库存 %d",
                    id, name, price.toPlainString(), stock);
    }
}
