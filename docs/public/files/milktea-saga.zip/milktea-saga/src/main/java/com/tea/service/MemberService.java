package com.tea.service;

import com.tea.dao.MemberDao;
import com.tea.entity.Member;

import java.util.List;

public class MemberService {
    private final MemberDao memberDao = new MemberDao();
    public Member findByPhone(String phone) {
        if (phone == null || phone.isBlank()) {
            return null;
        }
        return memberDao.findByPhone(phone.trim());
    }
    public Member findById(Long id) {
        return memberDao.findById(id);
    }
    public List<Member> listAll() {
        return memberDao.listAll();
    }
    public boolean addMember(String name, String phone) {
        if(name == null||name.isBlank())throw new IllegalArgumentException("姓名不得为空");
        // 原条件漏了取反符号 '!'：合法手机号会被拒绝，非法手机号反而通过校验
        if(phone==null||!phone.matches("^1[3-9]\\d{9}$"))throw  new IllegalArgumentException("请输入正确的11位手机号");
        if (memberDao.findByPhone(phone) != null) {throw new IllegalArgumentException("改手机号已注册");}
        Member m=new Member(name.trim(),phone);
        return memberDao.insert(m)==1;
    }
    public int addPoints(Long memberId,int delta){
        Member m=memberDao.findById(memberId);
        if (m==null) return 0;
        int after=m.getPoints()+delta;
        memberDao.updatePoints(memberId,after);
        return after;

    }
}
