package com.tea.service;

import com.tea.dao.OrderItemDao;
import com.tea.dao.TeaOrderDao;
import com.tea.entity.Drink;
import com.tea.entity.OrderItem;
import com.tea.entity.TeaOrder;
import com.tea.util.DbUtil;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

//下单服务
public class OrderService {
    private final TeaOrderDao teaOrderDao=new TeaOrderDao();
    private final OrderItemDao orderItemDao=new OrderItemDao();
    private final DrinkService  drinkService=new DrinkService();
    private final MemberService memberService=new MemberService();

    public record PlaceOrderResult(Long orderId, BigDecimal totalPrice,Integer pointsAfter){}
        /**
         * 下单核心：在一个事务里完成
         *   1) 校验库存（事务开始前查一遍，失败则不开事务）
         *   2) INSERT tea_order
         *   3) INSERT 每条 order_item
         *   4) UPDATE drink 扣库存
         *   5) UPDATE member 加积分（散客跳过）
         *
         * @param memberId 会员 ID，散客传 null
         * @param items    内存里组装好的明细列表（drinkId + quantity + unitPrice）
         */
        public PlaceOrderResult placeOrder(Long memberId, List<OrderItem> items){
            if(items==null||items.isEmpty()){
                throw new IllegalArgumentException("订单至少要一杯");
            }

            // ---- 事务前的轻校验：每杯都得有库存 ----
            for (OrderItem it : items) {
                Drink d = drinkService.findById(it.getDrinkId());
                if (d == null || d.getIsActive() == 0) {
                    throw new IllegalArgumentException("奶茶不存在或已下架：id=" + it.getDrinkId());
                }
                if (d.getStock() < it.getQuantity()) {
                    throw new IllegalArgumentException(
                            String.format("库存不足：%s 仅剩 %d 杯", d.getName(), d.getStock()));
                }
            }
            // ---- 计算总金额（用 BigDecimal 累加，不能用 double）----
            BigDecimal total = BigDecimal.ZERO;
            for (OrderItem it : items) {
                total = total.add(it.getSubtotal());
            }
            Connection conn=null;
            try{
                conn= DbUtil.getConnection();
                conn.setAutoCommit(false);
                //插订单主表
                TeaOrder order=new TeaOrder();
                order.setMemberId(memberId);
                order.setTotalAmount(total);
                order.setStatus("PAID");
                Long orderId=teaOrderDao.insertWithConn(conn,order);
                //插入每条明细
                for(OrderItem item : items){
                    item.setOrderId(orderId);
                    orderItemDao.insertWithConn(conn,item);
                    decrementStock(conn,item.getDrinkId(),item.getQuantity());
                }
                //加积分
                Integer pointsAfter=null;
                // 原判断写成 if(pointsAfter!=null)，但此时 pointsAfter 恒为 null，
                // 结果会员下单永远不会加积分；这里应判断 memberId（散客才跳过）
                if(memberId!=null){
                    int delta=total.intValue();
                    pointsAfter=addPointsInTx(conn,memberId,delta);
                }
                conn.commit();
                return new PlaceOrderResult(orderId,total,pointsAfter);


            } catch (Exception e) {
                if(conn!=null){
                    try{conn.rollback();}catch(SQLException ignore){}
                }
                throw new RuntimeException("下单失败，已回滚："+e.getMessage(),e);
            }finally {
                if(conn!=null){
                    try {
                        conn.setAutoCommit(true);
                    }catch(SQLException ignore){}
                    try{conn.close();}catch(SQLException ignore){}
                }
            }
        }
        //扣库存
        private void decrementStock(Connection conn,Long drinkId,Integer quantity)throws SQLException{
            String sql="UPDATE drink SET stock=stock-? WHERE id=? AND stock>=?";
            try (PreparedStatement ps=conn.prepareStatement(sql)) {
                ps.setInt(1, quantity);
                ps.setLong(2, drinkId);
                ps.setInt(3, quantity);
                int n=ps.executeUpdate();
                if(n!=1) {
                    throw new SQLException("扣库存失败（可能超卖）：drinkId="+drinkId);
                }
            }
        }
        //加积分
        private int addPointsInTx(Connection conn,Long memberId,int delta) throws SQLException{
            // 原 SQL 多了不存在的 memberId 列，而且只有 2 次赋值却写了 3 个占位符，
            // 积分逻辑一旦执行就会抛 SQLException 并回滚整笔订单
            String sql="UPDATE member SET points=points+? WHERE id=?";
            try (PreparedStatement ps=conn.prepareStatement(sql)) {
                ps.setInt(1, delta);
                ps.setLong(2, memberId);
                ps.executeUpdate();
            }
            // 查询积分变化后的值，复用同一个连接
            String q="SELECT points FROM member WHERE id=?";
            try (PreparedStatement ps=conn.prepareStatement(q)) {
                ps.setLong(1, memberId);
                try (var rs=ps.executeQuery()) {
                    if(rs.next()){return rs.getInt(1);}
                }
            }
            return -1;
        }

        //对外查询接口
        public TeaOrder findOrderById(Long orderId){
            return teaOrderDao.findById(orderId);
        }
        public List<OrderItem> findItemByOrderId(Long orderId){
            return orderItemDao.findByOrderIdWithDrinkName(orderId);
        }
}
