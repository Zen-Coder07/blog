package com.tea.dao;

import com.tea.entity.Drink;
import com.tea.util.DbUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DrinkDao {
    //查询所有在售奶茶
    public List<Drink> listAllDrink(){
        String sql ="SELECT id,name,category,price,stock,is_active "
                +"FROM drink WHERE is_active = 1 ORDER BY category,id";
        List<Drink> drinkList =new ArrayList<Drink>();
        try(Connection conn= DbUtil.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs=ps.executeQuery()){
            while(rs.next()){
                drinkList.add(map(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("查询奶茶列表失败",e);
        }
        return drinkList;
    }

    //价格快照
    public Drink findById(Long id){
        String sql ="SELECT id,name,category,price,stock,is_active "+
                " FROM drink WHERE id = ?";
        try (Connection conn=DbUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)){
            // 原代码漏了 ps.setLong(1, id) 就执行查询，
            // 会抛 "No value specified for parameter 1"，导致按 ID 查奶茶全部失败
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if(rs.next()){
                    return map(rs);
                }
                return null;
            }
        } catch (SQLException e) {
            throw new RuntimeException("查询奶茶失败",e);
        }
    }

    //新增奶茶
    public int insert(Drink d){
        String sql="INSERT INTO drink (name,category,price,stock,is_active) VALUES (?,?,?,?,1)";
        try (Connection conn=DbUtil.getConnection();
        PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)){
            ps.setString(1, d.getName());
            ps.setString(2, d.getCategory());
            ps.setBigDecimal(3, d.getPrice());
            ps.setInt(4, d.getStock());
            int n=ps.executeUpdate();
            try (ResultSet keys=ps.getGeneratedKeys()){
                if(keys.next()){
                    d.setId(keys.getLong(1));
                }
            }
            return  n;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    //修改价格&库存
    public int updatePriceAndStock(Long id,java.math.BigDecimal price,Integer stock){
        String sql="UPDATE drink SET price=? ,stock=? WHERE id=?";
        try (Connection conn=DbUtil.getConnection();
        PreparedStatement ps= conn.prepareStatement(sql)){
            ps.setBigDecimal(1, price);
            ps.setInt(2, stock);
            ps.setLong(3, id);
            return ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("修改奶茶失败",e);
        }
    }

    //下架（软删除）
    public int deactivate(Long id){
        String sql="UPDATE drink SET is_active=0 WHERE id=?";
        try (Connection conn=DbUtil.getConnection();
        PreparedStatement ps=conn.prepareStatement(sql)){
            ps.setLong(1, id);
            return ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("下架奶茶失败",e);
        }
    }

    public List<Drink> listLowStock(int threshold){
        String sql ="SELECT id,name,category,price,stock,is_active "
                +"FROM drink WHERE is_active=1 AND stock<? ORDER BY stock";
        List<Drink> drinkList =new ArrayList<>();
        try (Connection conn=DbUtil.getConnection();
        PreparedStatement ps=conn.prepareStatement(sql)){
            ps.setInt(1,threshold);
            try (ResultSet rs= ps.executeQuery()){
                while (rs.next()){
                    drinkList.add(map(rs));
                }
            }
        }catch (SQLException e){
            throw new RuntimeException("库存查询失败",e);
        }
        return drinkList;
    }


    private Drink map(ResultSet rs) throws SQLException {
        Drink d = new Drink();
        d.setId(rs.getLong("id"));
        d.setName(rs.getString("name"));
        d.setCategory(rs.getString("category"));
        d.setPrice(rs.getBigDecimal("price"));
        d.setStock(rs.getInt("stock"));
        d.setIsActive(rs.getInt("is_active"));
        return d;

    }
}
