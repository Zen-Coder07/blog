package com.tea.dao;

import com.tea.entity.Member;
import com.tea.util.DbUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MemberDao {
    public Member findByPhone(String phone) {
        String sql = "select id,name,phone,points,created_at "
                +"FROM member WHERE phone = ?";  // 原表名写成 members，实际建表是 member，会报 Table doesn't exist
        try (Connection conn= DbUtil.getConnection();
             PreparedStatement ps=conn.prepareStatement(sql)){
            ps.setString(1,phone);
            try(ResultSet rs=ps.executeQuery()){
                if(rs.next()){
                    return map(rs);
                }
                return null;
            }
        }catch (SQLException e) {
            throw new RuntimeException("按手机号查询会员失败",e);
        }
    }

        public Member findById(Long id) {
        String sql = "select id,name,phone,points,created_at "+
                "FROM member WHERE id = ?";  // 同上：members -> member
        try (Connection conn=DbUtil.getConnection();
        PreparedStatement ps= conn.prepareStatement(sql)){
            ps.setLong(1,id);
            try(ResultSet rs=ps.executeQuery()){
                if(rs.next()){return map(rs);}
                return null;
            }
        } catch (SQLException e) {
            throw new RuntimeException("按id查询会员失败",e);
        }
    }

    public List<Member> listAll() {
        String sql = "SELECT id,name,phone,points,created_at "+
                "FROM member ORDER BY id DESC ";
        List<Member> list = new ArrayList<>();
        try (Connection conn = DbUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()){
            while(rs.next()){list.add(map(rs));}
        } catch (SQLException e) {
            throw new RuntimeException("查询会员列表失败",e);
        }
        return list;
    }

    public int insert(Member member) {
        String sql ="INSERT INTO member (name,phone,points) VALUES (?,?,?)";
        try (Connection conn=DbUtil.getConnection();
        PreparedStatement ps= conn.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS)){
            ps.setString(1,member.getName());
            ps.setString(2,member.getPhone());
            ps.setInt(3,member.getPoints()==null?0:member.getPoints());
            int n = ps.executeUpdate();
            try (ResultSet rs=ps.getGeneratedKeys()){
                if(rs.next()){
                    member.setId(rs.getLong(1));
                }
            }
            return n;
        } catch (SQLException e) {
            throw new RuntimeException("更新积分失败",e);
        }
    }

    public int updatePoints(Long id,Integer points) {
        String sql ="UPDATE member SET points=? WHERE id=?";
        try (Connection conn=DbUtil.getConnection();
        PreparedStatement ps=conn.prepareStatement(sql)){
            ps.setInt(1,points);
            ps.setLong(2,id);
            return ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }



    private Member map(ResultSet rs) throws SQLException {
        Member member = new Member();
        member.setId(rs.getLong("id"));
        member.setName(rs.getString("name"));
        member.setPhone(rs.getString("phone"));
        member.setPoints(rs.getInt("points"));
        Timestamp ts=rs.getTimestamp("created_at");
        if(ts!=null){
            member.setCreatedAt(ts.toLocalDateTime());
        }
        return member;
    }
}
