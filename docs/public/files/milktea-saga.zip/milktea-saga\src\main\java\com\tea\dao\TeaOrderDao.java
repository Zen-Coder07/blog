package com.tea.dao;

import com.mysql.cj.xdevapi.Type;
import com.tea.entity.TeaOrder;
import com.tea.util.DbUtil;

import java.sql.*;

public class TeaOrderDao{
    public Long insertWithConn(Connection conn, TeaOrder order) throws SQLException {
        String sql="INSERT INTO tea_order (member_id,total_amount,status) VALUES (?,?,?)";
        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            if(order.getMemberId()==null){
                ps.setNull(1, Types.BIGINT);
            }else{
                ps.setLong(1, order.getMemberId());
            }
            ps.setBigDecimal(2, order.getTotalAmount());
            ps.setString(3, order.getStatus());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    Long id=rs.getLong(1);
                    order.setId(id);
                    return id;
                }
            }
        }
        throw new SQLException("订单插入未返回主键");
    }
    public TeaOrder findById(Long id) {
        // 原列名写成 create_at，建表语句实际是 created_at，查询会直接报 Unknown column
        String sql="SELECT id,member_id,total_amount,status,created_at "+
                "FROM tea_order WHERE id=?";
        try(Connection conn= DbUtil.getConnection();
        PreparedStatement ps = conn.prepareStatement(sql);){
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()){
                if(rs.next()){
                    TeaOrder order=new TeaOrder();
                    order.setId(rs.getLong("id"));
                    long mid=rs.getLong("member_id");
                    order.setMemberId(rs.wasNull()?null:mid);
                    order.setTotalAmount(rs.getBigDecimal("total_amount"));
                    order.setStatus(rs.getString("status"));
                    // 取值列名同样要从 create_at 改为 created_at
                    Timestamp ts=rs.getTimestamp("created_at");
                    if(ts!=null){
                        order.setCreatedAt(ts.toLocalDateTime());
                    }
                    return order;
                }
                return null;
            }
        } catch (SQLException e) {
            throw new RuntimeException("查询订单失败",e);
        }
    }
}
