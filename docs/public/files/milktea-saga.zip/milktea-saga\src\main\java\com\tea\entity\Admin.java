package com.tea.entity;

import java.time.LocalDateTime;

public class Admin {
    private Long id;
    private String username;
    private String password;
    private LocalDateTime createdAt;
    public  Admin() {
    }
    public Admin(String username, String password) {
        this.username = username;
        this.password = password;
    }
    public Long getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }
    public String getPassword() {
        return password;
    }
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public void setUsername(String username) {
        this.username = username;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
    public void getCreatedAt(LocalDateTime localDateTime) {
        this.createdAt = localDateTime;
    }
    @Override
    public String toString(){
        return "Admin{id=" + id + ", username='" + username + "'}";
    }


}
