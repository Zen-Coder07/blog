package com.tea.entity;

import com.tea.util.DbUtil;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;

public class TeaOrder {
    private Long id;
    private Long memberId;
    private BigDecimal totalAmount=BigDecimal.valueOf(0);
    private String status;
    private LocalDateTime createAt;
    public  TeaOrder() {
    }
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public Long getMemberId() {
        return memberId;
    }
    public void setMemberId(Long memberId) {
        this.memberId = memberId;
    }
    public BigDecimal getTotalAmount() {
        return totalAmount;
    }
    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public LocalDateTime getCreatedAt() {
        return createAt;
    }
    public void setCreatedAt(LocalDateTime createAt) {
        this.createAt = createAt;
    }
    public java.util.List<TeaOrder>listOrdersByMemberId(Long memberId){
        String sql="SELECT o.id,o.member_id,o.total_amount,o.status,o.created_at "
                + "FROM tea_order o "
                +"WHERE o.member_id=? "
                +"ORDER BY o.created_at DESC";
        java.util.List<TeaOrder> list=new java.util.ArrayList<>();
        try(Connection conn= DbUtil.getConnection();
            PreparedStatement ps=conn.prepareStatement(sql)){
            ps.setLong(1,memberId);
            try (ResultSet rs=ps.executeQuery()){
                while(rs.next()){
                    TeaOrder o=new TeaOrder();
                    o.setId(rs.getLong("id"));
                    long mid=rs.getLong("member_id");
                    o.setMemberId(rs.wasNull()?null:mid);
                    o.setTotalAmount(rs.getBigDecimal("total_amount"));
                    o.setStatus(rs.getString("status"));
                    java.sql.Timestamp ts=rs.getTimestamp("created_at");
                    if(ts!=null){
                        o.setCreatedAt(ts.toLocalDateTime());
                    }
                    list.add(o);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return list;
    }
}
